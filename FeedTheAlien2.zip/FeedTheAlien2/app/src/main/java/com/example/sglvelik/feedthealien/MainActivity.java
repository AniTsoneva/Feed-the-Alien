package com.example.sglvelik.feedthealien;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    /* Views */
    private TextView textScore; // the score
    private TextView initiateGame; // start the game
    private ImageView alien; // our alien
    private ImageView cookie; // 10 points
    private ImageView redbull; // speed increase
    private ImageView strawberry; // 100 points
    private ImageView bomb; // game over
    /* end Views */

    /* Dimensions */
    private int windowWidth; // the screen width
    private int windowHeight; // the screen height
    private int frameHeight; // the frame height
    private int alienSize; // the alien object dimensions
    /* end Dimensions */

    /* Positions */
    private int alienY; // alien vertical position
    private int cookieX; // cookie horizontal position
    private int cookieY; // cookie vertical position
    private int strawberryX; // strawberry horizontal position
    private int strawberryY; // strawberry vertical position
    private int redbullX; // redbull horizontal position
    private int redbullY; // redbull vertical position
    private int bombX; // bomb horizontal position
    private int bombY; // bomb vertical position
    /* end Positions */

    private int speed = 0; // the speed increase this is only doing something if the redbull is eaten
    private int score = 0; // the score of the user

    private Handler handler = new Handler(); // this will control the timer
    private Timer timer = new Timer(); // this is the timer which will move the game and when the game is over it will stop so no movement is done

    private boolean aFlag = false; // flag to know if the screen is touched or not
    private boolean initiateFlag = false; // flag to know if the screen is active or not

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // assigning the views
        textScore = findViewById(R.id.textScore);
        initiateGame = findViewById(R.id.initiateGame);
        alien = findViewById(R.id.alien);
        strawberry = findViewById(R.id.strawberry);
        cookie = findViewById(R.id.cookie);
        redbull = findViewById(R.id.redbull);
        bomb = findViewById(R.id.bomb);

        // accessing shared preferences so we find what is the alien type
        SharedPreferences settings = getSharedPreferences("GAME_DATA", Context.MODE_PRIVATE);
        String alienType = settings.getString("alien_type", "");

        // change the alien image
        switch(alienType){
            case "alien":
                alien.setImageResource(R.drawable.alien);
                break;
            case "aliengreen":
                alien.setImageResource(R.drawable.aliengreen);
                break;
            case "alien3":
                alien.setImageResource(R.drawable.alien3);
                break;
            case "alien4":
                alien.setImageResource(R.drawable.alien4);
                break;
            default:
                alien.setImageResource(R.drawable.alien);
                break;
        }

        WindowManager windowManage = getWindowManager();
        Display display = windowManage.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);

        // setting the with and height of the window
        windowWidth = size.x;
        windowHeight = size.y;

        // the alien should be in the middle
        alienY = frameHeight/2;
        alien.setY(alienY);

        // all other attributes will be outside of the screen until the game starts
        cookie.setX(windowWidth+80);
        cookie.setY(windowHeight+80);
        strawberry.setX(windowWidth+80);
        strawberry.setY(windowHeight+80);
        redbull.setX(windowWidth+80);
        redbull.setY(windowHeight+80);
        bomb.setX(windowWidth+80);
        bomb.setY(windowHeight+80);

        // create the timer thread
        timer.schedule(new TimerTask(){
           public void run(){
               handler.post(new Runnable(){
                   public void run(){
                       changePos();
                   }
               });
           }
        },0,20);
    }

    public void changePos(){
        if(initiateFlag){ // check if game is initiated
            cookieX=cookieX-(int)(Math.random()*30) - speed; // the speed with which the attribute will move to the left
            if(cookieX<0){ // if it reaches the end it will return back to initial position on a random vertical position
                cookieX = windowWidth + 20;
                cookieY = (int)Math.floor(Math.random()*(windowHeight-cookie.getHeight()));
            }
            // setting the location
            cookie.setX(cookieX);
            cookie.setY(cookieY);

            strawberryX=strawberryX-(int)(Math.random()*30) - speed; // the speed with which the attribute will move to the left
            if(strawberryX<0){ // if it reaches the end it will return back to initial position on a random vertical position
                strawberryX = windowWidth + 1000;
                strawberryY = (int)Math.floor(Math.random()*(windowHeight-strawberry.getHeight()));
            }
            // setting the location
            strawberry.setX(strawberryX);
            strawberry.setY(strawberryY);

            redbullX = redbullX -(int)(Math.random()*30) - speed; // the speed with which the attribute will move to the left
            if(redbullX <0){ // if it reaches the end it will return back to initial position on a random vertical position
                redbullX = windowWidth + 200;
                redbullY = (int)Math.floor(Math.random()*(windowHeight- redbull.getHeight()));
            }
            // setting the location
            redbull.setX(redbullX);
            redbull.setY(redbullY);

            bombX=bombX-(int)(Math.random()*30) - speed; // the speed with which the attribute will move to the left
            if(bombX<0){ // if it reaches the end it will return back to initial position on a random vertical position
                bombX = windowWidth + 500;
                bombY = (int)Math.floor(Math.random()*(windowHeight-bomb.getHeight()));
            }
            // setting the location
            bomb.setX(bombX);
            bomb.setY(bombY);

            eat(); // this method will check if the alien is over an atribute and will "eat" it
        }

        // if screen is touched
        if(aFlag){
            alienY = alienY - 40;
        }
        else{ // if it is not touched
            alienY = alienY + 40;
        }
        // if below the frame
        if(alienY<0){
            alienY = 0; // return it into the frame
        }
        else if(alienY >= frameHeight - alienSize){ // if above the frame
            alienY = frameHeight - alienSize; // return it into the frame
        }
        // set the location
        alien.setY(alienY);

        textScore.setText("Score: " + score); // and set the score after movement is done
    }

    // the method which will "eat" the attributes
    private void eat(){
        int cookieCenterX = cookieX + cookie.getWidth()/2; // the horizontal center of the attribute
        int cookieCenterY = cookieY + cookie.getHeight()/2; // the vertical center of the attribute
        int strawberryCenterX = strawberryX + strawberry.getWidth()/2; // the horizontal center of the attribute
        int strawberryCenterY = strawberryY + strawberry.getHeight()/2; // the vertical center of the attribute
        int planeCenterX = redbullX + redbull.getWidth()/2; // the horizontal center of the attribute
        int planeCenterY = redbullY + redbull.getHeight()/2; // the vertical center of the attribute
        int bombCenterX = bombX + bomb.getWidth()/2; // the horizontal center of the attribute
        int bombCenterY = bombY + bomb.getHeight()/2; // the vertical center of the attribute

        // these ifs will check if any of the attributes' centres are intersecting the alien and will return them to an initial position
        // or will give boost for example (change the speed variable)
        // or will end the game (the bomb)
        if(alienY + alienSize >= cookieCenterY && alienY <= cookieCenterY && alienSize >= cookieCenterX && cookieCenterY >=0){
            score = score+10;
            cookieX = -20;
        }
        if(alienY + alienSize >= strawberryCenterY && alienY <= strawberryCenterY && alienSize >= strawberryCenterX && strawberryCenterY >=0){
            score = score+100;
            strawberryX = -2000;
        }
        if(alienY + alienSize >= planeCenterY && alienY <= planeCenterY && alienSize >= planeCenterX && planeCenterY >=0){
            redbullX = -500;
            speed = 20;
            // the speed boost will last only for 5 seconds
            new CountDownTimer(5000, 1000) {
                public void onTick(long millisUntilFinished) {}
                public void onFinish() {
                    speed=0;
                }
            }.start();
        }
        if(alienY + alienSize >= bombCenterY && alienY <= bombCenterY && alienSize >= bombCenterX && bombCenterY >=0){
            bombX = -250;
            timer.cancel(); // stop the timer
            timer=null;
            Intent intent = new Intent(getApplicationContext(), result.class);
            intent.putExtra("SCORE", score); // send the score to result class
            startActivity(intent); // start the result class
        }
    }

    // this method will react only when the screen is touched
    public boolean onTouchEvent(MotionEvent touch){

        if(!initiateFlag){// checks if the game has started
            initiateFlag = true; // tell the activity that the screen has been touched

            FrameLayout frame = (FrameLayout) findViewById(R.id.frame);
            frameHeight = frame.getHeight(); // set the frame height

            alienY = (int)alien.getY(); // get the position of the alien

            alienSize = alien.getHeight(); // set the alien size

            initiateGame.setVisibility(View.GONE); // get rid of the initiate text
        }
        else{ // if the game is activated
            if(touch.getAction()==MotionEvent.ACTION_DOWN){ // the touch is being pressed
                aFlag = true;
            }
            else if(touch.getAction() == MotionEvent.ACTION_UP){ // the touch is not pressed
                aFlag = false;
            }
            alien.setY(alienY); // set position of the alien
        }

        return true;
    }
}
