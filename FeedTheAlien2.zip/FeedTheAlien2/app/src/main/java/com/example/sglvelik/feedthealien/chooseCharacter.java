package com.example.sglvelik.feedthealien;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class chooseCharacter extends AppCompatActivity {

    String alienType = "alien"; // the alien type

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_character);
    }

    public void playGame(View view){
        // we will now save the alien type to the GAME_DATA preferences and will access it into the MainActivity
        SharedPreferences settings = getSharedPreferences("GAME_DATA", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("alien_type", alienType);
        editor.commit(); // commit the changes
        startActivity(new Intent(getApplicationContext(), MainActivity.class)); // start main activity class
    }

    public void purpleAlien(View view){ // if pressed purple alien
        alienType = "alien";
    }
    public void greenAlien(View view){ // if pressed green alien
        alienType = "aliengreen";
    }
    public void whiteAlien(View view){ // if pressed white alien
        alienType = "alien3";
    }
    public void blackAlien(View view){ // if pressed black alien
        alienType = "alien4";
    }
}
