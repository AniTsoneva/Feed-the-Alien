package com.example.sglvelik.feedthealien;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Calendar;

// this class will work out the results
public class result extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // get all the views for the final screen
        TextView scorePoints = findViewById(R.id.scorePoints);
        TextView high_score = findViewById(R.id.highscore);
        TextView nameText = findViewById(R.id.name);
        TextView dateText = findViewById(R.id.date);

        int score = getIntent().getIntExtra("SCORE", 0); // the score the user has achieved
        scorePoints.setText(""+score); // set the current achieved view to the score
        Calendar c = Calendar.getInstance(); // this will get a date
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy"); // this will format the date
        String formattedDate = df.format(c.getTime()); // this will be the formatted date

        SharedPreferences settings = getSharedPreferences("GAME_DATA", Context.MODE_PRIVATE); // access the GAME_DATA preferences

        // getting all the variables stored into GAME_DATA
        int highScore = settings.getInt("highest_score", 0);
        String name = settings.getString("temp_name", "");
        String dateOld = settings.getString("the_date", "");
        String nameOld = settings.getString("the_name", "");

        if(score>highScore){ // if the achieved score is bigger than the highest score

            // we will set everything to the achieved score
            high_score.setText("Highest score: " + score);
            nameText.setText("by " + name);
            dateText.setText("on " + formattedDate);

            // save them to the preferences to access them again later
            SharedPreferences.Editor editor = settings.edit();
            editor.putInt("highest_score", score);
            editor.putString("the_name", name);
            editor.putString("the_date", formattedDate);
            editor.commit();
        }
        else{ // if the score is not bigger than the highest score
            // we will just display the highest values
            high_score.setText("Highest score: " + highScore);
            nameText.setText("by " + nameOld);
            dateText.setText("on " + dateOld);
        }
    }
    public void retry(View view){ // if we want to retry
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
    }
    public void returnMain(View view){ // if we want to return to main menu
        startActivity(new Intent(getApplicationContext(), MainMenu.class));
    }
}
