package com.example.sglvelik.feedthealien;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

// this class will get the player name
public class getName extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_name);
    }

    public void play(View view){ // if pressed the button play
        // we will now save the temp_name to the GAME_DATA
        EditText name = findViewById(R.id.name);
        SharedPreferences settings = getSharedPreferences("GAME_DATA", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("temp_name", name.getText().toString());
        editor.commit(); // submit the changes
        startActivity(new Intent(getApplicationContext(), chooseCharacter.class)); // start the choose character class
    }

    public void back(View view){ // if chose to go back
        startActivity(new Intent(getApplicationContext(), MainMenu.class)); // start the main menu class again
    }
}
