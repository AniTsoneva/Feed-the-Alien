package com.example.sglvelik.feedthealien;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
    }

    public void playGame(View view){ // if chose to play the game
        startActivity(new Intent(getApplicationContext(), getName.class)); // start the getName class
    }

    public void aboutGame(View view){ // if chose to learn more about the game
        startActivity(new Intent(getApplicationContext(), About.class)); // start the about class
    }
}
